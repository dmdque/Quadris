#include "tetromino.h"

class OBlock : public Tetromino{
public:
	void setPos(int o);
	OBlock();
};
