#include "tetromino.h"

class LBlock : public Tetromino{	
 public:
	void setPos(int o);
	LBlock();
};
