#include "tetromino.h"

class ZBlock : public Tetromino{
public:
	void setPos(int o);
	ZBlock();
};
