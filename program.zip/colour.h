#ifndef __COLOUR_H__
#define __COLOUR_H__

int colourBlock(char c);

#endif
