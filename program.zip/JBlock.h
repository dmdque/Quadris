#include "tetromino.h"

class JBlock : public Tetromino{
public:
	void setPos(int o);
	JBlock();
};
