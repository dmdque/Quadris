#include "tetromino.h"

class SBlock : public Tetromino{
public:
	void setPos(int o);
	SBlock();
};
