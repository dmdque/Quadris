#include "tetromino.h"

class TBlock : public Tetromino{
public:
	void setPos(int o);
	TBlock();
};
